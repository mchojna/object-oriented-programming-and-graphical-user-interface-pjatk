package EnumsPackage;

public enum TypSamochodu {
    OSOBOWY, DOSTAWCZY, ZABYTKOWY, DARMO
}