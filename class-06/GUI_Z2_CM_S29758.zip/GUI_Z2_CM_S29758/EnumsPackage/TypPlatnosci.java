package EnumsPackage;

public enum TypPlatnosci {
    KARTA, PRZELEW;
}